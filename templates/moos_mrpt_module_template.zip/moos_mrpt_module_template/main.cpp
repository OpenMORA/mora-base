/* +---------------------------------------------------------------------------+
   |                 Open MORA (MObile Robot Arquitecture)                     |
   +---------------------------------------------------------------------------+ */

#define MORA_APP_CLASS         CFooApp     
#define MORA_APP_NAME          "Foo"    // Default MOOSApp app name

#include <mora_main.h>


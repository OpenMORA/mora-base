/* +---------------------------------------------------------------------------+
   |                 Open MORA (MObile Robot Arquitecture)                     |
   |                  University of Almeria ARM-eCar module                    |
   |                                                                           |
   |   Copyright (C) 2014  University of Almeria                               |
   +---------------------------------------------------------------------------+ */

/**  @moos_module YOUR SHORT DESCRIPTION OF THE MODULE IN ONE LINE OR MORE  */

#include "CFooApp.h"

#include <sstream>
#include <iomanip>
#include <iostream>

using namespace std;

using namespace mrpt;
using namespace mrpt::slam;
using namespace mrpt::utils;
//using namespace ....


CFooApp::CFooApp() 
//	: var (init_val), ...
{
}

CFooApp::~CFooApp()
{
}

bool CFooApp::OnStartUp()
{
	// If want a different mode than standard: 
	// - REGULAR_ITERATE_AND_MAIL
	// - COMMS_DRIVEN_ITERATE_AND_MAIL
	// - REGULAR_ITERATE_AND_COMMS_DRIVEN_MAIL
	//SetIterateMode(REGULAR_ITERATE_AND_MAIL); 

	// Read parameters (if any) from the mission configuration file.
	//! @moos_param PARAM_NAME  PARAM DESCRIPTION IN ONE LINE
	m_MissionReader.GetConfigurationParam("my_param",m_myvar);

	// There is also a MRPT-like object (this->m_ini) that is a wrapper
	//  to read from the module config block of the current MOOS mission file.
	// m_ini.read_int(...);
	return DoRegistrations();
}

bool CFooApp::OnCommandMsg( CMOOSMsg Msg )
{
	if(Msg.IsSkewed(MOOSTime())) return true;
	if(!Msg.IsString()) return MOOSFail("This module only accepts string command messages\n");
	const std::string sCmd = Msg.GetString();
	//MOOSTrace("COMMAND RECEIVED: %s\n",sCmd.c_str());
	// Process the command "sCmd".

	return true;
}

bool CFooApp::Iterate()
{
	// Are there 
	CMOOSVariable *var1 = GetMOOSVar("MY_SUBSCRIBED_VAR1");
	if (var1 && var1->IsFresh())
	{
		var1->SetFresh(false);
		// Do whatver with this new information
		//var1->...
	}

	// Main module loop code. Do the main stuff here...


	//!  @moos_var   MY_PUBLISHED_VAR1  This var is the blah blah...
	//!  @moos_publish   MY_PUBLISHED_VAR1
	m_Comms.Notify("MY_PUBLISHED_VAR1", var_value );

	return true;
}

bool CFooApp::OnConnectToServer()
{
	DoRegistrations();
	return true;
}


bool CFooApp::DoRegistrations()
{
	//! @moos_subscribe	MY_SUBSCRIBED_VAR1, MY_SUBSCRIBED_VAR2, MY_SUBSCRIBED_VAR3
	AddMOOSVariable(
		"MY_SUBSCRIBED_VAR1", "MY_SUBSCRIBED_VAR1", "MY_SUBSCRIBED_VAR1", 
		0 /* Minimum time in seconds between updates */ );

	RegisterMOOSVariables();
	RegisterMOOSVariables_MAPIR();
	return true;
}


bool CFooApp::OnNewMail(MOOSMSG_LIST &NewMail)
{
	UpdateMOOSVariables(NewMail);
	UpdateMOOSVariables_MAPIR(NewMail);
	return true;
}
